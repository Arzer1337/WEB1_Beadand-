let unfinishedCount = 0; 

function hozzaadas() {
    const taskText = document.getElementById("text").value.trim();
    if (taskText === "") {
        alert("Kérlek, adj meg egy feladatot!");
        return;
    }

    const todoList = document.getElementById("todoList");

    const taskItem = document.createElement("li");
    taskItem.classList.add("list-group-item", "d-flex", "justify-content-between", "align-items-center");

    const taskLabel = document.createElement("span");
    taskLabel.textContent = taskText;

    const checkmark = document.createElement("span");
    checkmark.innerHTML = "✔"; 
    checkmark.classList.add("text-success", "ms-3");
    checkmark.style.cursor = "pointer";

   
    checkmark.addEventListener("click", () => {
        if (!taskItem.classList.contains("completed")) {
            taskItem.classList.add("completed");
            checkmark.style.color = "gray";
            unfinishedCount--;
            updateUnfinishedCount();
        }
    });

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "X";
    deleteButton.classList.add("btn", "btn-danger", "btn-sm");
    
   
    deleteButton.onclick = () => {
        if (!taskItem.classList.contains("completed")) {
            unfinishedCount--; 
        }
        todoList.removeChild(taskItem);
        updateUnfinishedCount();
    };

    taskItem.appendChild(taskLabel);
    taskItem.appendChild(checkmark);
    taskItem.appendChild(deleteButton);

    todoList.appendChild(taskItem);

    document.getElementById("text").value = ""; 
    unfinishedCount++; 
    updateUnfinishedCount(); 
}

function updateUnfinishedCount() {
    const unfinishedCountElement = document.getElementById("unfinishedCount");
    unfinishedCountElement.textContent = `Befejezetlen teendők: ${unfinishedCount}`;
}
