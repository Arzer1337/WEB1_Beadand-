const rectangle = document.getElementById("rectangle");
const translateXInput = document.getElementById("translateX");
const translateYInput = document.getElementById("translateY");
const rotateInput = document.getElementById("rotate");
const scaleInput = document.getElementById("scale");
const skewXInput = document.getElementById("skewX");
const skewYInput = document.getElementById("skewY");
const resetButton = document.getElementById("reset");


function applyTransformations() {
  const translateX = translateXInput.value || 0;
  const translateY = translateYInput.value || 0;
  const rotate = rotateInput.value || 0;
  const scale = scaleInput.value || 1;
  const skewX = skewXInput.value || 0;
  const skewY = skewYInput.value || 0;

 
  const transform = `
    translate(${translateX}px, ${translateY}px)
    rotate(${rotate}deg)
    scale(${scale})
    skew(${skewX}deg, ${skewY}deg)
  `;
  rectangle.style.transform = transform;
}


translateXInput.addEventListener("input", applyTransformations);
translateYInput.addEventListener("input", applyTransformations);
rotateInput.addEventListener("input", applyTransformations);
scaleInput.addEventListener("input", applyTransformations);
skewXInput.addEventListener("input", applyTransformations);
skewYInput.addEventListener("input", applyTransformations);

resetButton.addEventListener("click", () => {
  translateXInput.value = 0;
  translateYInput.value = 0;
  rotateInput.value = 0;
  scaleInput.value = 1;
  skewXInput.value = 0;
  skewYInput.value = 0;
  applyTransformations();
});